$(document).ready(function(){
            
    $(".carousel-item").addClass('animated slideInUp');
    
});