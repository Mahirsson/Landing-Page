$(document).ready(function(){
            
    $(".carousel-caption h5").addClass('animated slideInLeft');
    
    $(".carousel-caption p").addClass('animated slideInRight');
    
});